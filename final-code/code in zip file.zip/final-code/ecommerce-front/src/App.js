import React from "react";

const App = () => <div>Hello from React</div>;

export default App;
